@extends ('layouts.admin')
@section ('contenido')


	<div class="row">
		
		<div class="col-lg-8 col-sm-8 col-md-6 col-xs-8">
				
				<div class="form-group">
				

					<label for="nombre">Aceeso Denegado</label>
					
					
				</div>

		</div>



</div>			

@endsection

