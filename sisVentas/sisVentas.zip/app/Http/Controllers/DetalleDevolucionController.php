<?php

namespace sisVentas\Http\Controllers;

use Illuminate\Http\Request;

use sisVentas\Http\Requests;

class DetalleDevolucionController extends Controller
{
    //
}
