<?php

namespace sisVentas;

use Illuminate\Database\Eloquent\Model;

class NotaCredito extends Model
{
    //
}
