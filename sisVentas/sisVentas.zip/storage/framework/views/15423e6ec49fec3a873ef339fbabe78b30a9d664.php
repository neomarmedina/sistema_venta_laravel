 <?php 

if(Auth::user()->tipoUsuario=='2'){

?>

<!! con la etiqueta meta estoy redireccionando al modulo de ventas  !!>
<meta http-equiv="refresh" content="0; /avisos/aviso" />

<?php

}
?>

<?php $__env->startSection('contenido'); ?>





<section class="content-header">
     
      <ol class="breadcrumb">
        <li><a href="<?php echo e(url('/home')); ?>"><i class="fa fa-dashboard"></i> Panel de control
        <li><a href="#"><i class="fa fa-truck"></i> Abastecer almacen</a></li>
        
        
      </ol>
    </section>




<div class="row">
  
    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
        <h3>Abastecer almacen<a href="ingreso/create">  <button class="btn btn-success">Registrar Ingreso</button><a/></h3>
        <?php echo $__env->make('compras.ingreso.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

</div>


<div class="row">
  
     <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          
          <div class="table-reponsive">
            
                <table class="table table-bordered table-striped" width="1070">
                  
                      <thead>
                        
                          
                          <th>Fecha</th>
                           <th>Proveedor</th>
                           <th>Comprobante</th>
                        
                           <th>Impuesto</th>
                           <th>Total</th>
                           <th>Estado</th>
                           <th>Opciones</th>

                     </thead>


                    <?php foreach($ingresos as $ing): ?>
                      <tr>
                       
                        <td><?php echo e($ing->fecha_hora); ?></td>
                        <td><?php echo e($ing->nombre); ?></td>
                        <td><?php echo e($ing->tipo_comprobante.': '.$ing->serie_comprobante.'-'.$ing->num_comprobante); ?></td>
               
                        <td><?php echo e($ing->impuesto); ?></td>
                        <td><?php echo e($ing->total); ?></td>
                        <td><?php echo e($ing->estado); ?></td>
                        <td>
                               <a href="<?php echo e(URL::action('IngresoController@show',$ing->idingreso)); ?>"> <button class="btn btn-primary">Detalles</button></a>
                              <a href="" data-target="#modal-delete-<?php echo e($ing->idingreso); ?>" data-toggle=modal ><button class="btn btn-danger">Alunar</button></a>
                        </td>       
                      </tr>  


                      <?php echo $__env->make('compras.ingreso.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                      <?php endforeach; ?>

                </table>


          </div>

          <?php echo e($ingresos->render()); ?>



     </div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>