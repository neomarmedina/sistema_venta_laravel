<?php $__env->startSection('contenido'); ?>

<section class="content-header">
     
      <ol class="breadcrumb">
        <li><a href="<?php echo e(url('/home')); ?>"><i class="fa fa-dashboard"></i> Panel de control
        <li><a href="<?php echo e(url('ventas/cliente')); ?>"><i class="fa fa-shopping-cart"></i> Gestionar Cliente</a></li>
        <li><a href="#"> Editar Cliente
        
      </ol>
    </section>

	<div class="row">
		
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
				
				<h3>Editar Cliente</h3>
				
						<?php if(count($errors)>0): ?>

						<div class="alert alert-danger">
							<ul>
					

									<?php foreach($errors->all() as $error): ?>
					
											<li><?php echo e($error); ?></li>

									<?php endforeach; ?>

							</ul>

						</div>
						<?php endif; ?>
		</div>				 
    </div>

<?php echo Form::model($persona,['method'=>'PATCH','route'=>['ventas.cliente.update',$persona->idpersona]]); ?>

						
							<?php echo e(Form::token()); ?>


	<div class="row">
		
		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
				
				<div class="form-group">
				

									<label for="nombre">Nombre</label>
									<input type="text" name="nombre" required value="<?php echo e($persona->nombre); ?>" class="form-control" placeholder="Nombre..."></input>								
				</div>

		</div>




<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
		

				<div class="form-group">
				

									<label for="direccion">Dirección</label>
									<input type="text" name="direccion" required value="<?php echo e($persona->direccion); ?>" class="form-control" placeholder="Dirección del cliente..."></input>								
				</div>




		</div>



<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
		
					<div class="form-group">

							<label> Tipo de documento</label>

								<select name="tipo_documento" class="form-control">
									
										<?php if($persona->tipo_documento=='CI'): ?>
										
											<option selected value="CI">CI</option>
											<option value="RIF">RIF</option>
											<option value="PAS">PAS</option>
										<?php elseif($persona->tipo_documento=='RIF'): ?>	

										
											<option value="CI">CI</option>
											<option selected value="RIF">RIF</option>
											<option value="PAS">PAS</option>
										<?php else: ?>
										
										    <option value="CI">CI</option>
											<option value="RIF">RIF</option>
											<option selected value="PAS">PAS</option>


										<?php endif; ?>
									
									
								</select>
				
					</div>



		</div>




		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
		

				<div class="form-group">
				

									<label for="num_documento">Numero de Doc.</label>
									<input type="text" name="num_documento" required value="<?php echo e($persona->num_documento); ?>" class="form-control" placeholder="Número de Doc..."></input>								
				</div>




		</div>
		


		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
		

				<div class="form-group">
				

									<label for="telefono">Teléfono</label>
									<input type="text" name="telefono" value="<?php echo e($persona->telefono); ?>" class="form-control" placeholder="Teléfono del cliente..."></input>								
				</div>






		</div>
		

<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
		

				<div class="form-group">
				

									<label for="email">Email</label>
									<input type="text" name="email" value="<?php echo e($persona->email); ?>" class="form-control" placeholder="Email del cliente..."></input>														
</div>

<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
		

				<div class="form-group">
				

									<label for="codigo">Código</label>
									<input type="text" name="codigo" value="<?php echo e($persona->codigo); ?>" class="form-control" placeholder="Código del cliente..."></input>														
</div>
				




		</div>




			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
	

							<div class="form-group">
								<button class="btn btn-primary" type="submit">Guardar</button>
								<button class="btn btn-danger" type="reset">Cancelar</button>
							</div>
								

			</div>
								
</div>


								



						<?php echo Form::close(); ?>

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>