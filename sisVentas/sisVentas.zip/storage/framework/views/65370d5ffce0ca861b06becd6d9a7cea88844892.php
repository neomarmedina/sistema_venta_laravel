<?php $__env->startSection('contenido'); ?>


<section class="content-header">
     
      <ol class="breadcrumb">
        <li><a href="<?php echo e(url('/home')); ?>"><i class="fa fa-dashboard"></i> Panel de control
        <li><a href="<?php echo e(url('tiendas/tienda')); ?>"><i class="fa fa-institution"></i> Gestionar Tiendas</a></li>
        <li><a href="#"> Editar Tienda
        
      </ol>
    </section>


	<div class="row">
		
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
				
				<h3>Editar Tienda <?php echo e($tienda->nombre); ?></h3>
				
						<?php if(count($errors)>0): ?>

						<div class="alert alert-danger">
							<ul>
					

									<?php foreach($errors->all() as $error): ?>
					
											<li><?php echo e($error); ?></li>

									<?php endforeach; ?>

							</ul>

						</div>
						<?php endif; ?>



						<?php echo Form::model($tienda,['method'=>'PATCH','route'=>['tiendas.tienda.update',$tienda->idtienda]]); ?>

						
							<?php echo e(Form::token()); ?>


								<div class="form-group">
									<label for="nombre">Nombre</label>
									<input type="text" name="nombre" class="form-control" value="<?php echo e($tienda->nombre); ?>" placeholder="Nombre..."></input>								

								</div>



								<div class="form-group">
									<label for="descripcion">Descripción</label>
									<input type="text" name="descripcion" class="form-control"  value="<?php echo e($tienda->descripcion); ?>" placeholder="Descripcion..."></input>								

								</div>

								<div class="form-group">
									<label for="direccion">Dirección</label>
									<input type="text" name="direccion" class="form-control"  value="<?php echo e($tienda->direccion); ?>" placeholder="Dirección..."></input>								

								</div>


								<div class="form-group">
				

									<label for="telefono">Teléfono</label>
									<input type="text" name="telefono" value="<?php echo e($tienda->telefono); ?>" class="form-control" placeholder="Teléfono del cliente..."></input>								
								</div>
								<div class="form-group">
				

									<label for="rif">Rif.</label>
									<input type="text" name="rif" value="<?php echo e($tienda->rif); ?>" class="form-control" placeholder="Rif. de la Empresa..."></input>								
								</div>

									<div class="form-group">
				

									<label for="codigo">Código.</label>
									<input type="text" name="codigo" value="<?php echo e($tienda->codigo); ?>" class="form-control" placeholder="Código de la Empresa..."></input>								
								</div>

								<div class="form-group"></div>
								<button class="btn btn-primary" type="submit">Guardar</button>
								<button class="btn btn-danger" type="reset">Cancelar</button>
								


						<?php echo Form::close(); ?>

		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>