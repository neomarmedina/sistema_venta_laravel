<?php $__env->startSection('contenido'); ?>

<div class="row">
  
    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
        <h3>Consultar Articulos</h3>
        <?php echo $__env->make('almacen.articulo.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>

</div>


<div class="row">
  
     <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          
          <div class="table-reponsive">
            
                <table class="table-striped table-bordered table-condensed table-hover" width="1070">
                  
                      <thead>
                        
                          <th>Id</th>
                          <th>Nombre</th>
                           <th>Código</th>
                           <th>Categoría</th>
                           <th>Marca</th>
                           <th>Modelo</th>
                           
                           <th>Talla</th>
                           <th>Stock</th>
                           <th>Imagen</th>
                           
                               
                     </thead>


                    <?php foreach($articulos as $art): ?>
                      <tr>
                        <td><?php echo e($art->idarticulo); ?></td>
                        <td><?php echo e($art->nombre); ?></td>
                        <td><?php echo e($art->codigo); ?></td>
                        <td><?php echo e($art->categoria); ?></td>
                        <td><?php echo e($art->marca); ?></td>
                        <td><?php echo e($art->modelo); ?></td>
                        
                        <td><?php echo e($art->talla); ?></td>
                        <td><?php echo e($art->stock); ?></td>
                        <td>

                        <img src="<?php echo e(asset('imagenes/articulos/'.$art->imagen)); ?>" alt="<?php echo e($art->nombre); ?>" height="100" width="100" class="img-thumbnail">

                        </td>
                            
                      </tr>  


                      <?php echo $__env->make('almacen.articulo.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                      <?php endforeach; ?>

                </table>


          </div>

          <?php echo e($articulos->render()); ?>



     </div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>