<?php $__env->startSection('contenido'); ?>

<section class="content-header">
     
      <ol class="breadcrumb">
        <li><a href="<?php echo e(url('/home')); ?>"><i class="fa fa-dashboard"></i> Panel de control
        <li><a href="<?php echo e(url('almacen/articulo')); ?>"><i class="fa fa-laptop"></i> Gestionar Articulo</a></li>
        <li><a href="#"> Editar Articulo
        
      </ol>

	<div class="row">
		
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
				
				<h3>Editar Articulo : <?php echo e($articulo->nombre); ?></h3>
				
						<?php if(count($errors)>0): ?>

						<div class="alert alert-danger">
							<ul>
					

									<?php foreach($errors->all() as $error): ?>
					
											<li><?php echo e($error); ?></li>

									<?php endforeach; ?>

							</ul>

						</div>
						<?php endif; ?>

			</div>
    </div>




						<?php echo Form::model($articulo,['method'=>'PATCH','route'=>['almacen.articulo.update',$articulo->idarticulo],'files'=>'true']); ?>

						
							<?php echo e(Form::token()); ?>





<div class="row">
		
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
				
				<h3>Nuevo Articulo</h3>
				
						<?php if(count($errors)>0): ?>

						<div class="alert alert-danger">
							<ul>
					

									<?php foreach($errors->all() as $error): ?>
					
											<li><?php echo e($error); ?></li>

									<?php endforeach; ?>

							</ul>

						</div>
						<?php endif; ?>
		</div>				 
     </div>


				<?php echo Form::open(array('url'=>'almacen/articulo','method'=>'POST','autocomplete'=>'off','files'=>'true')); ?>

						
				<?php echo e(Form::token()); ?>


	<div class="row">
		
		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
				
				<div class="form-group">
				

									<label for="nombre">Nombre</label>
									<input type="text" name="nombre" required value="<?php echo e($articulo->nombre); ?>" class="form-control"></input>								
				</div>

		</div>
		
		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
		
					<div class="form-group">

							<label> Categoría</label>

								<select name="idcategoria" class="form-control">
					
									<?php foreach($categorias as $cat): ?>
									<?php if($cat->idcategoria==$articulo->idcategoria): ?>	

										<option value="<?php echo e($cat->idcategoria); ?>" selected><?php echo e($cat->nombre); ?></option>
									<?php else: ?>
									<option value="<?php echo e($cat->idcategoria); ?>"><?php echo e($cat->nombre); ?></option>
									<?php endif; ?>

									<?php endforeach; ?>
								</select>
				
					</div>



		</div>
		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
		

				<div class="form-group">
				

									<label for="codigo">Código</label>
									<input type="text" name="codigo" required value="<?php echo e($articulo->codigo); ?>" class="form-control"></input>								
				</div>




		</div>
		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
		

				<div class="form-group">
				

									<label for="stock">Stock</label>
									<input type="text" name="stock" required value="<?php echo e($articulo->stock); ?>" class="form-control"></input>								
				</div>




		</div>



		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
		

				<div class="form-group">
				

									<label for="descripcion">Descripción</label>
									<input type="text" name="descripcion" value="<?php echo e($articulo->descripcion); ?>" class="form-control" placeholder="Descripción del articulo..."></input>								
				</div>


		</div>

		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
		

				<div class="form-group">
				

									<label for="marca">Marca</label>
									<input type="text" name="marca" value="<?php echo e($articulo->marca); ?>" class="form-control" placeholder="Marca del articulo..."></input>								
				</div>






		</div>


		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
		

				<div class="form-group">
				

									<label for="modelo">Modelo</label>
									<input type="text" name="modelo" value="<?php echo e($articulo->modelo); ?>" class="form-control" placeholder="Modelo del articulo..."></input>								
				</div>


		</div>





		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
		

				<div class="form-group">
				

									<label for="unidad_medida">Uni.Medida</label>
									<input type="text" name="unidad_medida" value="<?php echo e($articulo->unidad_medida); ?>" class="form-control" placeholder="Unidad de Medida..."></input>								
				</div>


		</div>


		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
		

				<div class="form-group">
				

									<label for="talla">Talla</label>
									



								<select name="idtalla" class="form-control">
					
									<?php foreach($talla as $tall): ?>
									<?php if($tall->idtalla==$articulo->idtalla): ?>	

										<option value="<?php echo e($tall->idtalla); ?>" selected><?php echo e($tall->nombre); ?></option>
									<?php else: ?>
									<option value="<?php echo e($tall->idtalla); ?>"><?php echo e($tall->nombre); ?></option>
									<?php endif; ?>

									<?php endforeach; ?>
								</select>								
				






				</div>






		</div>
		


<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
		

				<div class="form-group">
				

									
						<label for="estado">Estado</label>
						

						<select name="estado" class="form-control">
					
									

										<option value="Activo" selected>Activo</option>
								
									<option value="Inactivo">Inactivo</option>
								
								</select>	



				</div>






		</div>




<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
		

				<div class="form-group">
				

									<label for="imagen">Imagen</label>
									<input type="file" name="imagen"  class="form-control">	
									<?php if(($articulo->imagen!="")): ?>
										<img src="<?php echo e(asset('imagenes/articulos/'.$articulo->imagen)); ?>" height="300px width="300px" ">
									<?php endif; ?>

				</div>

				




	</div>




		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
		

				<div class="form-group">
				

									
				</div>


		</div>

		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
		

				<div class="form-group">
				

									
				</div>


		</div>



			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
	

							<div class="form-group">
								<button class="btn btn-primary" type="submit">Guardar</button>
								<button class="btn btn-danger" type="reset">Cancelar</button>
							</div>
								

			</div>
								
</div>

								

						<?php echo Form::close(); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>