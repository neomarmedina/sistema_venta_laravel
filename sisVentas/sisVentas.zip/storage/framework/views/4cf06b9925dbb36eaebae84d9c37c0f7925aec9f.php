<?php 

if(Auth::user()->tipoUsuario=='2'){

?>

<!! con la etiqueta meta estoy redireccionando al modulo de ventas  !!>
<meta http-equiv="refresh" content="0; /avisos/aviso" />

<?php

}
?>

<?php $__env->startSection('contenido'); ?>

<section class="content-header">
     
      <ol class="breadcrumb">         <li><a href="<?php echo e(url('/home')); ?>"><i class="fa
fa-dashboard"></i> Panel de control         <li><a href="calcular_comisiones"><i class="fa fa-
shopping-cart"></i> Comisones</a></li>
       
      </ol>
    </section>





<div class="row">
  
    <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
        <h3> Actualmente este vendedor no posee comisiones acumuladas...
    </div>



<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>