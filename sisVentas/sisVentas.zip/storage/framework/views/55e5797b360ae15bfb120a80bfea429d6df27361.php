<?php $__env->startSection('contenido'); ?>


<section class="content-header">
     
      <ol class="breadcrumb">
        <li><a href="<?php echo e(url('/home')); ?>"><i class="fa fa-dashboard"></i> Panel de control
        <li><a href="<?php echo e(url('compras/proveedor')); ?>"><i class="fa fa-th"></i> Gestionar Proveedor</a></li>
        <li><a href="#"> Registrar Proveedor
        
      </ol>
    </section>

	<div class="row">
		
		<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
				
				<h3>Registrar Proveedor</h3>
				
						<?php if(count($errors)>0): ?>

						<div class="alert alert-danger">
							<ul>
					

									<?php foreach($errors->all() as $error): ?>
					
											<li><?php echo e($error); ?></li>

									<?php endforeach; ?>

							</ul>

						</div>
						<?php endif; ?>
		</div>				 
    </div>


				<?php echo Form::open(array('url'=>'compras/proveedor','method'=>'POST','autocomplete'=>'off')); ?>

						
				<?php echo e(Form::token()); ?>


	<div class="row">
		
		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
				
				<div class="form-group">
				

									<label for="nombre">Nombre</label>
									<input type="text" name="nombre" required value="<?php echo e(old('nombre')); ?>" class="form-control" placeholder="Nombre..."></input>								
				</div>

		</div>
		





	<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
		

				<div class="form-group">
				

									<label for="direccion">Dirección</label>
									<input type="text" name="direccion" required value="<?php echo e(old('direccion')); ?>" class="form-control" placeholder="Dirección del cliente..."></input>								
				</div>

		</div>






		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
		
					<div class="form-group">

						<label for="tipo_documento">Documento</label>
						

						<select name="tipo_documento" class="form-control">
					
									
										<option value="CI">C.I</option>
										<option value="RIF">RIF</option>
										<option value="PAS">PAS</option>

								
								</select>
					</div>



		</div>
		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
		

				<div class="form-group">
				

									<label for="num_documento">Número de documento</label>
									<input type="text" name="num_documento" required value="<?php echo e(old('num_documento')); ?>" class="form-control" placeholder="Número de Doc..."></input>								
				</div>




		</div>
	
		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
		

				<div class="form-group">
				

									<label for="codigo">Código</label>
									<input type="text" name="codigo" required value="<?php echo e(old('codigo')); ?>" class="form-control" placeholder="Código del Provee..."></input>								
				</div>




		</div>


		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
		

				<div class="form-group">
				

									<label for="telefono">Teléfono</label>
									<input type="text" name="telefono" value="<?php echo e(old('telefono')); ?>" class="form-control" placeholder="Teléfono del cliente..."></input>								
				</div>






		</div>
		

<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
		

				<div class="form-group">
				

									<label for="email">Email</label>
									<input type="text" name="email" value="<?php echo e(old('email')); ?>" class="form-control" placeholder="Email del cliente..."></input>														
				</div>

				




		</div>




			<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
	

							<div class="form-group">
								<button class="btn btn-primary" type="submit">Guardar</button>
								<button class="btn btn-danger" type="reset">Cancelar</button>
							</div>
								

			</div>
								
</div>


								



<?php echo Form::close(); ?>

	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>